package zoo;


/**
 *
 * @author Aluno
 */
    public class cachorro extends animal{
	private String ataqueEspecial;
	
    public cachorro(String nome, int numeroDePatas, int idade) {
        super(nome, numeroDePatas, idade);
        ataqueEspecial = "Correr";
    }

	public void emiteSom()
	{
		System.out.println ("Au Au");
        }

    public String getAtaqueEspecial()
    {
		return ataqueEspecial;
    }


}