package zoo;

public abstract class animal{
	private String nome;
	private int numeroDePatas;
	private int idade;

	public animal(String nome,int numeroDePatas,int idade)
	{
		this.nome = nome;
		this.numeroDePatas = numeroDePatas;
		this.idade = idade;
	}	
	
	abstract void emiteSom();
        
        public String getNome(){
		return nome;
    }

        public int numeroDePatas(){
		return numeroDePatas;
        }

      public int getIdade(){
		return idade;
         }
}