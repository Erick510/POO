import java.util.ArrayList;
import zoo.animal;



/**
 *
 * @author Aluno
 */
public class veterinário{

    public veterinário(){

    }

	public void examinar( ArrayList animais){
                int i;
                animal ani = (animal) animais.get(0);
		for (i=0; i < animais.size() ; i++){
			System.out.println(ani.getNome() + ", seu som é: " + ani.emiteSom() + ", possui: " + ani.numeroDePatas() + " patas e " + ani.getIdade() + " de idade.");
						
		
                  }
        }
}
