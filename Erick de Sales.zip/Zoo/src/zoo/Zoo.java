/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoo;

import java.util.ArrayList;

/**
 *
 * @author Aluno
 */
public class Zoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	ArrayList<animal> zoo = new ArrayList<>();
    	veterinário vet = new veterinário();

    	zoo.add(new gato("Frajola", 4, 5));
       	zoo.add(new gato("Garfield", 4, 6));
    	zoo.add(new gato("Tom", 4, 7));
    	zoo.add(new gato("Mingau", 4, 8));
    	zoo.add(new vaca("Cow", 4, 9));
    	zoo.add(new vaca("Vaquinha", 4, 10));
    	zoo.add(new vaca("Boi", 4, 11));
    	zoo.add(new vaca("Touro", 4, 12));
    	zoo.add(new cachorro("Scooby", 4, 13));
    	zoo.add(new cachorro("Marley", 4, 14));
    	zoo.add( new cachorro("Bob", 4, 15));
    	zoo.add( new cachorro("Spot", 4, 16));

    	vet.examinar(zoo);


    }
    
}
