package zoo;


/**
 *
 * @author Aluno
 */
public class gato extends animal{
	private String ataqueEspecial;

    public gato(String nome, int numeroDePatas, int idade) {
        super(nome, numeroDePatas, idade);
        ataqueEspecial = "Dormir";
    }

        @Override
    public void emiteSom(){
	System.out.println ("Miau");
    }

    public String getAtaqueEspecial(){
		return ataqueEspecial;
    }
}
