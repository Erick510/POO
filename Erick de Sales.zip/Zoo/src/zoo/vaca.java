package zoo;

/**
 *
 * @author Aluno
 */
public class vaca extends animal{
	private String ataque_especial;
	
    public vaca(String nome, int numeroDePatas, int idade) {
        super(nome, numeroDePatas, idade);
        ataque_especial = "Produzir Leite";
    }

	public void emiteSom()
	{
		System.out.println ("Muuuuu");
          }


}